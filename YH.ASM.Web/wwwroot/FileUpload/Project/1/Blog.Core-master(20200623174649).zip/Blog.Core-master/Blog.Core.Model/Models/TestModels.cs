﻿using SqlSugar;
using System;

namespace Blog.Core.Model.Models
{

    public class TestMuchTableResult
    {
        public string moduleName { get; set; }
        public string permName { get; set; }
        public int rid { get; set; }
        public int mid { get; set; }
        public int? pid { get; set; }

    }
}
