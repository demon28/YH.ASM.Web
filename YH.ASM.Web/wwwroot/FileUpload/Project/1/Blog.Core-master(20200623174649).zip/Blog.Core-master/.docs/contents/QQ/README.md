## QQ 群

<img src="http://apk.neters.club/images/NETCore-VUE.png" alt="群1" width="200" >
<img src="http://apk.neters.club/images/NETCore-VUE-2.png" alt="群2" width="200" >


## 微信公众号

<img src="http://apk.neters.club/images/wechat.png" alt="公众号" width="600" >


