﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Blog.Core.Common.DB
{
    public static class MainDb
    {
        public static string CurrentDbConnId = "1";
    }
}
